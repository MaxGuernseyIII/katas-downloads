import XCTest
@testable import R2OCPTests

XCTMain([
  testCase(BasicTransfers.allTests),
  testCase(TaxDeferredPlan.allTests),
  testCase(RothPlan.allTests),
])
