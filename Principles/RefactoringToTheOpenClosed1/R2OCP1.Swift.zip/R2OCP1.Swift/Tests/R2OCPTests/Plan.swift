﻿// MIT License
// 
// Copyright (c) 2018 Hexagon Software LLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

import XCTest
@testable import R2OCP;

public class Plan: XCTestCase {
  private var destination: Account = Account.GetInstance();
  private var originalDestinationBalance: Int = 0;
  private var originalSourceBalance: Int = 0;
  private var source: Account = Account.GetInstance();

  public override func setUp() {
    super.setUp()
    source = DSL.GivenAccount();
    destination = DSL.GivenAccount();
    originalSourceBalance = source.Balance;
    originalDestinationBalance = destination.Balance;
  }

  func ThenAmountWasTransferredWithTaxImplications(_ transferAmount: Int, _ lossAmount: Int, _ gainAmount: Int) {
    DSL.ThenAccountBalanceIs(source, originalSourceBalance - transferAmount);
    DSL.ThenAccountBalanceIs(destination, originalDestinationBalance + transferAmount);
    DSL.ThenLossWasRecorded(source, lossAmount);
    DSL.ThenGainWasRecorded(destination, gainAmount);
  }

  func WhenTransfer(_ amount: Int, _ taxRules: TaxRules) {
    DSL.WhenTransfer(source, destination, amount, taxRules);
  }

  func GivenDestinationTaxDeferrableAndWithdrawableAmount() -> Int {
    return DSL.GivenAmountUpTo(min(originalSourceBalance, destination.GoverningBody.GetTaxDeferredContributionLimit()));
  }

  func GivenSourceTaxDeferrableAndWithdrawableAmount() -> Int {
    return DSL.GivenAmountUpTo(min(originalSourceBalance, source.GoverningBody.GetTaxDeferredContributionLimit()));
  }

  func GivenDestinationNonTaxDeferrableAmount() -> Int {
    return destination.GoverningBody.GetTaxDeferredContributionLimit() + 1;
  }

  func GivenSourceNonTaxDeferrableAmount() -> Int {
    return source.GoverningBody.GetTaxDeferredContributionLimit() + 1;
  }

  func GivenWithdrawableAmount() -> Int {
    return DSL.GivenAmountUpTo(source.Balance);
  }

  func GivenNonWithdrawableAmount() -> Int {
    return source.Balance + 1;
  }
}

