﻿// MIT License
// 
// Copyright (c) 2018 Hexagon Software LLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

import XCTest
import R2OCP

internal class DSL {
  internal static func GivenAmountUpTo(_ maximum: Int) -> Int {
    return AnyTestValue.IntegerUpTo(maximum);
  }

  internal static func ThenAccountBalanceIs(_ account: Account, _ amount: Int) {
    assert(account.Balance == amount)
  }

  internal static func GivenAccount() -> Account {
    let account = Account.GetInstance();
    account.Credit(AnyTestValue.Integer()).Commit();
    account.GoverningBody = MockGoverningBody();
    return account;
  }

  internal static func WhenTransfer(_ sourceAccount: Account, _ destinationAccount: Account, _ toTransfer: Int, _ taxRules: TaxRules) {
    TransferManager.GetInstance().Transfer(sourceAccount, destinationAccount, toTransfer, taxRules);
  }

  internal static func GivenGoverningBody() -> GoverningBody {
    return MockGoverningBody();
  }

  internal static func ThenLossWasRecorded(_ account: Account, _ amount: Int) {
    assert(account.GoverningBody.GetLosses(account) == amount)
  }

  internal static func ThenGainWasRecorded(_ account: Account, _ amount: Int) {
    assert(amount == account.GoverningBody.GetGains(account));
  }
}
