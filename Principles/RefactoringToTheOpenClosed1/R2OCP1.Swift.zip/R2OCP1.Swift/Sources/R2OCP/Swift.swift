struct Swift {
    var text = "Hello, World!"
}
