﻿// MIT License
// 
// Copyright (c) 2018 Hexagon Software LLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.


public class Account : Hashable {
  private static var nextId: Int = 0
  private var id : Int ;

  public var hashValue: Int {
    return id
  }

  public static func == (lhs: Account, rhs : Account) -> Bool{
    return lhs.hashValue == rhs.hashValue
  }

  class AccountAmountTransaction: Transaction {
    let account: Account;
    let amount: Int;

    init(_ account: Account, _ amount: Int) {
      self.account = account;
      self.amount = amount;
    }
  }

  private class CreditTransaction: AccountAmountTransaction {
    public override init(_ account: Account, _ amount: Int) {
      super.init(account, amount)
    }

    public override func Commit() {
      account.Balance += amount;
    }
  }

  private class DebitTransaction: AccountAmountTransaction {
    public override init(_ account: Account, _ amount: Int) {
      super.init(account, amount)
    }

    public override func Commit() {
      account.Balance -= amount;
    }
  }

  private init() {
    self.Balance = 0
    self.GoverningBody = NoGoverningBody()
    self.id = Account.nextId
    Account.nextId += 1
  }

  public var Balance: Int
  public var GoverningBody: GoverningBody

  public static func GetInstance() -> Account {
    return Account();
  }

  public func Credit(_ amount: Int) -> Transaction {
    return CreditTransaction(self, amount);
  }

  public func Debit(_ amount: Int) -> Transaction {
    return DebitTransaction(self, amount);
  }
}
