/*
 * MIT License
 *
 * Copyright (c) 2018 Hexagon Software LLC
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */


package katas;

public class Plan {
    private Account destination;
    private int originalDestinationBalance;
    private int originalSourceBalance;
    private Account source;

    protected void init() {
        source = DSL.givenAccount();
        destination = DSL.givenAccount();
        originalSourceBalance = source.getBalance();
        originalDestinationBalance = destination.getBalance();
    }

    protected void thenAmountWasTransferredWithTaxImplications(int transferAmount, int lossAmount, int gainAmount) {
        DSL.thenAccountBalanceIs(source, originalSourceBalance - transferAmount);
        DSL.thenAccountBalanceIs(destination, originalDestinationBalance + transferAmount);
        DSL.thenLossWasRecorded(source, lossAmount);
        DSL.thenGainWasRecorded(destination, gainAmount);
    }

    protected void whenTransfer(int amount, TaxRules taxRules) {
        DSL.whenTransfer(source, destination, amount, taxRules);
    }

    protected int givenDestinationTaxDeferrableAndWithdrawableAmount() {
        return DSL.givenAmountUpTo(Math.min(originalSourceBalance, destination.getGoverningBody().getTaxDeferredContributionLimit()));
    }

    protected int givenSourceTaxDeferrableAndWithdrawableAmount() {
        return DSL.givenAmountUpTo(Math.min(originalSourceBalance, source.getGoverningBody().getTaxDeferredContributionLimit()));
    }

    protected int givenDestinationNonTaxDeferrableAmount() {
        return destination.getGoverningBody().getTaxDeferredContributionLimit() + 1;
    }

    protected int GivenSourceNonTaxDeferrableAmount() {
        return source.getGoverningBody().getTaxDeferredContributionLimit() + 1;
    }

    protected int givenWithdrawableAmount() {
        return DSL.givenAmountUpTo(source.getBalance());
    }

    protected int givenNonWithdrawableAmount() {
        return source.getBalance() + 1;
    }
}

