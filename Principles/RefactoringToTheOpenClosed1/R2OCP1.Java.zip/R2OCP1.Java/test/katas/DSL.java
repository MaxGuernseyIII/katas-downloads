/*
 * MIT License
 *
 * Copyright (c) 2018 Hexagon Software LLC
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */


package katas;

import static org.junit.Assert.assertEquals;

class DSL {
    static int givenAmountUpTo(int maximum) {
        return Any.integerUpTo(maximum);
    }

    static void thenAccountBalanceIs(Account account, int amount) {
        assertEquals(account.getBalance(), amount);
    }

    static Account givenAccount() {
        Account account = Account.getInstance();
        account.credit(Any.integer()).commit();
        account.setGoverningBody(new MockGoverningBody());
        return account;
    }

    static void whenTransfer(Account sourceAccount, Account destinationAccount, int toTransfer, TaxRules taxRules) {
        TransferManager.getInstance().Transfer(sourceAccount, destinationAccount, toTransfer, taxRules);
    }

    static void thenLossWasRecorded(Account account, int amount) {
        assertEquals(amount, account.getGoverningBody().getLosses(account));
    }

    static void thenGainWasRecorded(Account account, int amount) {
        assertEquals(amount, account.getGoverningBody().getGains(account));
    }
}

