﻿export abstract class Source {

}