﻿export class InvalidOperationException extends Error {

}
