﻿// Copyright 2018-2018 Hexagon Software LLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.


public class Playback {
    public enum PlaybackError: Error {
        case InvalidOperation
    }

    public enum State {
        case PlayingMainSource
        case PlayingAd
        case Finished
    }

    public class Ad {
        private init(_ source: Source, _  position: Double) {
            Source = source
            Position = position
        }

        public private(set) var Source: Source
        public private(set) var Position: Double

        public static func GetInstance(_ source: Source, _ position: Double) -> Ad {
            return Ad(source, position)
        }
    }

    private var ads: [Ad]
    private var source: Source

    private var ui: UI
    private var currentPosition: Double
    private var currentSpeed: Double
    private var playingAd: Ad?
    private var state: State

    private init(_ ui: UI, _ source: Source, _ ads: [Ad]) {
        self.ui = ui
        self.source = source
        self.ads = ads
        self.currentSpeed = 1
        self.state = State.PlayingMainSource
        self.currentPosition = 0
        self.playingAd = nil

        OnPlayMainSource()

        self.ui.WatchPositionUpdated(OnPositionUpdate)
        self.ui.WatchSourceFinished(OnSourceFinished)
    }

    public var CurrentState: State {
        return state
    }

    public static let BoundaryDetectionTolerance = Double(0.1)

    public static func Start(_ ui: UI, _ source: Source, _ ads: [Ad]) -> Playback {
        return Playback(ui, source, ads)
    }

    private func OnPositionUpdate(_ newPosition: Double) throws {
        switch (state) {
        case State.PlayingMainSource:
            var _ = PlayNextAd(currentPosition, newPosition)
            currentPosition = newPosition
            break
        case State.PlayingAd:
            break
        case State.Finished:
            throw PlaybackError.InvalidOperation
        }
    }

    private func OnSourceFinished() throws {

        switch (state) {
        case State.PlayingAd:
            if (!PlayNextAd(playingAd!.Position, currentPosition)) {
                OnPlayMainSource()
            }
            break
        case State.PlayingMainSource:
            ui.Close()
            state = State.Finished
            break
        case State.Finished:
            throw PlaybackError.InvalidOperation
        }
    }

    private func OnPlayMainSource() {
        ui.Play(source, currentPosition)
        ui.FastForwardEnabled = true
        ui.PlaybackSpeed = currentSpeed
        state = State.PlayingMainSource
    }

    private func PlayNextAd(_ beforePosition: Double, _ afterPosition: Double) -> Bool {
        for ad in ads {
            if (beforePosition < ad.Position && afterPosition > ad.Position) {
                ui.Play(ad.Source, 0)
                ui.FastForwardEnabled = false
                currentSpeed = ui.PlaybackSpeed
                ui.PlaybackSpeed = 1
                state = State.PlayingAd
                playingAd = ad
                return true
            }

        }

        return false
    }
}
