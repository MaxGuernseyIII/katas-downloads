﻿// Copyright 2018-2018 Hexagon Software LLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

import Foundation
import XCTest
import Katas_SwitchToState1

public class PlaybackTests: XCTestCase {
    private var ui: MockPlaybackUI
    private var initialSource: MockSource
    private var ads: [Playback.Ad]
    private var playback: Playback

    public required init(name: String, testClosure: @escaping(XCTestCase) throws -> Void) {
        ui = MockPlaybackUI()
        initialSource = MockSource()
        ads = []
        playback = Playback.Start(ui, initialSource, ads)
        super.init(name: name, testClosure: testClosure)
    }

    public override func setUp() {
        ui = MockPlaybackUI()
        initialSource = MockSource()
        ads = []
    }

    public func testAdNotTriggeredWhilePlayingAnotherAd() throws {
        StartPlaybackWithAds()
        var _ = try CrossPosition(AdPosition(0))

        _ = try CrossPosition(AdPosition(1))

        ThereShouldBeNoPlayCalls()
    }

    public func testAdReturnsToOriginalPlaybackPosition() throws {
        StartPlaybackWithAds()

        let positionBeforeAd = try PlayEntireAd(0)

        StateShouldBe(Playback.State.PlayingMainSource)
        OnlyPlayCallShouldBe(initialSource, positionBeforeAd)
    }

    public func testBoundaryDetectionThreshold() {
        XCTAssertEqual(0.1, Playback.BoundaryDetectionTolerance)
    }

    public func testCannotFinishTwice() throws {
        StartPlayback()
        try SourceFinished()

        XCTAssertThrowsError(try SourceFinished()) {
            error in
            XCTAssertEqual(error as? Playback.PlaybackError, Playback.PlaybackError.InvalidOperation)
        }
    }

    public func testCannotSeekAfterFinish() throws {
        StartPlaybackWithAds()
        try SourceFinished()


        XCTAssertThrowsError(try PlayTo(AdPosition(2))) {
            error in
            XCTAssertEqual(error as? Playback.PlaybackError, Playback.PlaybackError.InvalidOperation)
        }
    }

    public func testExitAfterFinish() throws {
        StartPlayback()

        try SourceFinished()

        XCTAssertEqual(1, ui.CloseCalls)
        StateShouldBe(Playback.State.Finished)
    }

    public func testFastForwardDisabledDuringAdPlayback() throws {
        StartPlaybackWithAds()
        PlaybackSpeedIs(2)

        var _ = try CrossPosition(AdPosition(0))

        FastForwardShouldBeEnabled(false)
        PlaybackSpeedShouldBe(1)
    }

    public func testFinishingAdReEnablesFastforward() throws {
        StartPlaybackWithAds()
        PlaybackSpeedIs(3)

        var _ = try PlayEntireAd(0)

        FastForwardShouldBeEnabled(true)
        PlaybackSpeedShouldBe(3)
    }

    public func testInitialStateIsPlaying() {
        StartPlayback()

        StateShouldBe(Playback.State.PlayingMainSource)
        OnlyPlayCallShouldBe(initialSource, 0)
        FastForwardShouldBeEnabled(true)
        PlaybackSpeedShouldBe(1)
    }

    public func testLaunchAd() throws {
        StartPlaybackWithAds()

        var _ = try CrossPosition(AdPosition(0))

        StateShouldBe(Playback.State.PlayingAd)
        OnlyPlayCallShouldBe(AdSource(0), 0)
    }

    public func testSecondAdCanBePlayed() throws {
        StartPlaybackWithAds()
        var _ = try PlayEntireAd(0)
        ForgetUIHistory()

        _ = try CrossPosition(AdPosition(1))

        StateShouldBe(Playback.State.PlayingAd)
        OnlyPlayCallShouldBe(AdSource(1), 0)
    }

    public func testSkippingMultipleAdsInvokesBothInOrder() throws {
        var _ = StartPlaybackWithAds()
        try PlayTo(AdPosition(0) - Playback.BoundaryDetectionTolerance)
        try PlayTo(AdPosition(1) + Playback.BoundaryDetectionTolerance)
        _ = ForgetUIHistory()

        _ = try SourceFinished()

        OnlyPlayCallShouldBe(AdSource(1), 0)
        StateShouldBe(Playback.State.PlayingAd)
        XCTAssertEqual(0, ui.CloseCalls)
    }

    private func PlaybackSpeedIs(_ actual: Double) {
        ui.PlaybackSpeed = actual
    }

    private func PlaybackSpeedShouldBe(_ expected: Double) {
        XCTAssertEqual(expected, ui.PlaybackSpeed)
    }

    private func SourceFinished() throws {
        var _ = ForgetUIHistory()
        try ui.RaiseSourceFinished()
    }

    private func AdSource(_ v: Int) -> Source {
        return ads[v].Source
    }

    private func AdPosition(_ v: Int) -> Double {
        return ads[v].Position
    }

    private func StartPlaybackWithAds() {
        var _ = GivenAd(120.0)
        _ = GivenAd(600.0)
        _ = GivenAd(1200.0)
        StartPlayback()
    }

    private func GivenAd(_ position: Double) {
        ads.append(Playback.Ad.GetInstance(MockSource(), position))
    }

    private func CrossPosition(_ threshold: Double) throws -> Double {
        try PlayTo(threshold - Playback.BoundaryDetectionTolerance)
        ForgetUIHistory()
        let newPosition = threshold + Playback.BoundaryDetectionTolerance
        try PlayTo(newPosition)
        return newPosition
    }

    private func StateShouldBe(_ expected: Playback.State) {
        XCTAssertEqual(expected, playback.CurrentState)
    }

    private func StartPlayback() {
        playback = Playback.Start(ui, initialSource, ads)
    }

    private func PlayTo(_ position: Double) throws {
        try ui.RaisePositionUpdate(position)
    }

    private func ThereShouldBeNoPlayCalls() {
        XCTAssertEqual(0, ui.PlayCalls.count)
    }

    private func ForgetUIHistory() {
        ui.Reset()
    }

    private func OnlyPlayCallShouldBe(_ expectedSource: Source, _ expectedPosition: Double) {
        XCTAssertEqual(1, ui.PlayCalls.count)
        let (source, position) = ui.PlayCalls[0]
        XCTAssert(expectedSource === source)
        XCTAssertEqual(expectedPosition, position)
    }

    private func FastForwardShouldBeEnabled(_ v: Bool) {
        XCTAssertEqual(v, ui.FastForwardEnabled)
    }

    private func PlayEntireAd(_ ad: Int) throws -> Double {
        let positionBeforeAd = try CrossPosition(AdPosition(ad))
        try SourceFinished()

        return positionBeforeAd
    }

    static let allTests = [
        ("Ads not triggered during other ads", testAdNotTriggeredWhilePlayingAnotherAd),
        ("Ads return to original place in main source", testAdReturnsToOriginalPlaybackPosition),
        ("Boundary detection threshold", testBoundaryDetectionThreshold),
        ("Cannot finish twice", testCannotFinishTwice),
        ("Cannot seek after finish", testCannotSeekAfterFinish),
        ("Cannot end source after finish", testExitAfterFinish),
        ("Cannot fast forward during ad playback", testFastForwardDisabledDuringAdPlayback),
        ("Fast forward re-enabled after ad finishes", testFinishingAdReEnablesFastforward),
        ("Starts off attempting to play main source", testInitialStateIsPlaying),
        ("Launches ad when threshold is met", testLaunchAd),
        ("Launches second ad after first finishes", testSecondAdCanBePlayed),
        ("Launches long skip invokes multiple ads back-to-back", testSkippingMultipleAdsInvokesBothInOrder),
    ]
}
