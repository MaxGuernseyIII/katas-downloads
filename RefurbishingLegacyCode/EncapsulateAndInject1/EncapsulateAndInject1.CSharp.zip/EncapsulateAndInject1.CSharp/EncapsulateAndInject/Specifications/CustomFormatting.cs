﻿// Copyright 2018-2018 Hexagon Software LLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

using System;
using System.Collections.Generic;
using Implementation;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Specifications
{
    [TestClass]
    public class CustomFormatting
    {
        public class MockCondition : GridView.CellCondition
        {
            private readonly GridView.Cell cell;

            public MockCondition(GridView.Cell cell)
            {
                this.cell = cell;
            }

            public bool AppliesTo(GridView.Cell cell)
            {
                return this.cell == cell;
            }
        }

        public class MockCellStyleWriter : CustomGrid.CellStyleWriter
        {
            private readonly GridView.Cell cell;
            public Control.Color LastBackgroundColor;
            public bool? LastBorderCollapse;

            public Control.BorderType? LastBorderType;
            public double? LastBorderWeight;
            public bool? LastIsItalic;
            public bool? LastIsUnderlined;
            public Control.Color LastTextColor;
            public double? LastTextWeight;

            public MockCellStyleWriter(GridView.Cell cell)
            {
                this.cell = cell;
            }

            public void SetBorderType(Control.BorderType borderType)
            {
                LastBorderType = borderType;
            }

            public void SetBorderWeight(double weight)
            {
                LastBorderWeight = weight;
            }

            public void SetBackgroundColor(Control.Color color)
            {
                LastBackgroundColor = color;
            }

            public void SetTextColor(Control.Color color)
            {
                LastTextColor = color;
            }

            public void SetTextWeight(double weight)
            {
                LastTextWeight = weight;
            }

            public void SetTextUnderline(bool isUnderlined)
            {
                LastIsUnderlined = isUnderlined;
            }

            public void SetTextItalic(bool isItalic)
            {
                LastIsItalic = isItalic;
            }

            public void SetBorderCollapse(bool collapse)
            {
                LastBorderCollapse = collapse;
            }

            public GridView.Cell GetCell() => cell;
        }

        public class MockCell : GridView.Cell
        {
            public object Value { get; set; }

            public GridView.Column GetColumn()
            {
                throw new NotImplementedException();
            }

            public GridView.Row GetRow()
            {
                throw new NotImplementedException();
            }

            public Control GetControl()
            {
                throw new NotImplementedException();
            }
        }

        private MockCell cell;
        private MockCellStyleWriter cellStyleWriter;
        private Control.Color gray;
        private Control.Color orange;
        private IList<CustomGrid.StyleRule> styleRules;

        [TestInitialize]
        public void Setup()
        {
            cell = new MockCell();
            cellStyleWriter = new MockCellStyleWriter(cell);
            gray = new Control.Color(.5, .5, .5, 1);
            orange = new Control.Color(1, .8, 0, 1);
            styleRules = new List<CustomGrid.StyleRule>();
        }

        [TestMethod]
        public void ChangeBackgroundOfApplicableCell()
        {
            var styleMod = GivenAnyStyleModForApplicableRule();

            WhenStyleRulesAreApplied();

            ThenStyleModeWasApplied(styleMod);
        }

        [TestMethod]
        public void MultipleApplicableStylesAreMerged()
        {
            var styleMod1 = GivenBlankStyleModForApplicableRule();
            GivenNewBackgroundColor(styleMod1, gray);
            GivenNewBorderType(styleMod1, Control.BorderType.Dashed);
            var styleMod2 = GivenBlankStyleModForApplicableRule();
            GivenNewTextColor(styleMod2, orange);
            GivenNewBorderType(styleMod2, Control.BorderType.Double);

            WhenStyleRulesAreApplied();

            var expected = new StyleMod();
            expected.NewBackgroundColor = styleMod1.NewBackgroundColor;
            expected.NewTextColor = styleMod2.NewTextColor;
            expected.NewBorderType = styleMod2.NewBorderType;
            ThenStyleModeWasApplied(expected);
        }

        [TestMethod]
        public void InapplicableRuleNotApplied()
        {
            GivenAnyStyleModForInapplicableRule();

            WhenStyleRulesAreApplied();

            ThenStyleModeWasApplied(new StyleMod());
        }

        private void GivenAnyStyleModForInapplicableRule()
        {
            var result = new StyleMod();

            styleRules.Add(new CustomGrid.StyleRule(new MockCondition(null), result));

            GivenAnyStyleSettings(result);
        }

        private StyleMod GivenAnyStyleModForApplicableRule()
        {
            var styleMod = GivenBlankStyleModForApplicableRule();
            GivenAnyStyleSettings(styleMod);
            return styleMod;
        }

        private void GivenAnyStyleSettings(StyleMod styleMod)
        {
            GivenNewBackgroundColor(styleMod, gray);
            GivenNewTextColor(styleMod, orange);
            GivenNewBorderType(styleMod, Control.BorderType.Dashed);
            GivenNewBorderWeight(styleMod, .4);
            GivenNewIsItalic(styleMod, true);
            GivenNewIsUnderlined(styleMod, false);
            GivenNewTextWeight(styleMod, .5);
        }

        private static void GivenNewTextWeight(StyleMod styleMod, double weight)
        {
            styleMod.NewTextWeight = weight;
        }

        private void GivenNewIsUnderlined(StyleMod styleMod, bool isUnderlind)
        {
            styleMod.NewIsUnderlined = isUnderlind;
        }

        private static void GivenNewIsItalic(StyleMod styleMod, bool isItalic)
        {
            styleMod.NewIsItalic = isItalic;
        }

        private static void GivenNewBorderWeight(StyleMod styleMod, double weight)
        {
            styleMod.NewBorderWeight = weight;
        }

        private static void GivenNewBorderType(StyleMod styleMod, Control.BorderType borderType)
        {
            styleMod.NewBorderType = borderType;
        }

        private void GivenNewTextColor(StyleMod styleMod, Control.Color color)
        {
            styleMod.NewTextColor = color;
        }

        private StyleMod GivenBlankStyleModForApplicableRule()
        {
            var styleMod = new StyleMod();
            styleRules.Add(new CustomGrid.StyleRule(new MockCondition(cell), styleMod));
            return styleMod;
        }

        private static void GivenNewBackgroundColor(StyleMod styleMod, Control.Color newColor)
        {
            styleMod.NewBackgroundColor = newColor;
        }

        private void ThenStyleModeWasApplied(StyleMod styleMod)
        {
            Assert.AreEqual(styleMod.NewBackgroundColor, cellStyleWriter.LastBackgroundColor);
            Assert.AreEqual(styleMod.NewTextColor, cellStyleWriter.LastTextColor);
            Assert.AreEqual(styleMod.NewTextWeight, cellStyleWriter.LastTextWeight);
            Assert.AreEqual(styleMod.NewBorderType, cellStyleWriter.LastBorderType);
            Assert.AreEqual(styleMod.NewBorderWeight, cellStyleWriter.LastBorderWeight);
            Assert.AreEqual(styleMod.NewIsItalic, cellStyleWriter.LastIsItalic);
            Assert.AreEqual(styleMod.NewIsUnderlined, cellStyleWriter.LastIsUnderlined);
            Assert.AreEqual(null, cellStyleWriter.LastBorderCollapse);
        }

        private void WhenStyleRulesAreApplied()
        {
            Assert.Fail("Not implemented.");
        }
    }
}
