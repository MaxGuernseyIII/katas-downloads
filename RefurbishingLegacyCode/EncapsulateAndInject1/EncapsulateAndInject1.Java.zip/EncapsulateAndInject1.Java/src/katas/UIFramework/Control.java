// Copyright 2018-2018 Hexagon Software LLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.



package katas .UIFramework;

    public abstract class Control
    {
        public enum BorderType
        {
            None,
            Dashed,
            Dotted,
            Solid,
            Double,
        }

        public static class Color
        {
            public Color(double r, double g, double b, double a)
            {
                _R = r;
                _G = g;
                _B = b;
                _A = a;
            }

private double _R;             public double R() { return _R; }
private double _G;             public double G() { return _G; }
private double _B;             public double B() { return _B; }
private double _A;             public double A() { return _A; }
        }

        static
        {
            UI.requireUIThread();
        }

        protected Control()
        {
            UI.requireUIThread();
        }

        public abstract void updateStyle();

        // final
        public void SetBorderType(BorderType borderType)
        {
            UI.requireUIThread();
        }

        // final
        public void SetBorderWeight(double weight)
        {
            UI.requireUIThread();
        }

        // final
        public void SetBackgroundColor(Color color)
        {
            UI.requireUIThread();
        }

        // final
        public void SetTextColor(Color color)
        {
            UI.requireUIThread();
        }

        // final
        public void SetTextWeight(double weight)
        {
            UI.requireUIThread();
        }

        // final
        public void SetTextUnderline(boolean isUnderlined)
        {
            UI.requireUIThread();
        }

        // final
        public void SetTextItalic(boolean isItalic)
        {
            UI.requireUIThread();
        }

        // final
        public void SetBorderCollapse(boolean collapse)
        {
            UI.requireUIThread();
        }
    }

