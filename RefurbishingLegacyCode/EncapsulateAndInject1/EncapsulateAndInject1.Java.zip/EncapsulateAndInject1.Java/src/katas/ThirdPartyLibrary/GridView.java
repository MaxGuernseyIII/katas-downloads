// Copyright 2018-2018 Hexagon Software LLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.





package katas.ThirdPartyLibrary ;

import katas.UIFramework.Control;
import katas.UIFramework.UI;

import java.util.*;

public abstract class GridView extends Control
    {
        public interface Row
        {
            int GetPosition();
            Cell[] GetCells();
            Cell GetCell(String name);
            Cell GetCell(int ordinalPosition);
            Cell GetCell(Column column);
        }

        private class RowImpl implements Row
        {
            private final Map<Column, Cell> cells = new HashMap<>();
            private final GridView parent;

            public RowImpl(GridView parent)
            {
                this.parent = parent;

                for (Column parentColumn : this.parent.columns)
                    cells.put(parentColumn, new CellImpl(parent, this, parentColumn));
            }

            public int GetPosition()
            {
                return parent.rows.indexOf(this);
            }

            public Cell[] GetCells()
            {
                ArrayList<Cell> result = new ArrayList<>();
                for (Column column : parent.columns)
                    result.add(GetCell(column));

                return result.toArray(new Cell[0]);
            }

            public Cell GetCell(String name)
            {
                Column column = parent.GetColumn(name);

                return GetCell(column);
            }

            public Cell GetCell(int ordinalPosition)
            {
                return GetCell(parent.columns.get(ordinalPosition));
            }

            public Cell GetCell(Column column)
            {
                return cells.get(column);
            }
        }

        public interface Column
        {
            String GetName();
            int GetPosition();
            Cell[] GetCells();
            Cell GetCellByRowIndex(int index);
            Cell GetCell(Row row);
        }

        private class ColumnImpl implements Column
        {
            private final String name;
            private final GridView parent;

            public ColumnImpl(String name, GridView parent)
            {
                this.name = name;
                this.parent = parent;
            }

            public String GetName()
            {
                return name;
            }

            public int GetPosition()
            {
                return parent.columns.indexOf(this);
            }

            public Cell[] GetCells()
            {
                ArrayList<Cell> result = new ArrayList<>();

                for (Row row : parent.rows)
                    result.add(row.GetCell(this));

                return  result.toArray(new Cell[0]);
            }

            public Cell GetCellByRowIndex(int index)
            {
                return parent.rows.get(index).GetCell(this);
            }

            public Cell GetCell(Row row)
            {
                return row.GetCell(this);
            }
        }

        public interface Cell
        {
            Object Value() ;
            void Value(Object value) ;
            Column GetColumn();
            Row GetRow();
            Control GetControl();
        }

        private static class CellImpl implements Cell
        {
            private class CellControl extends Control
            {
                private final CellImpl cell;
                private final GridView parent;

                public CellControl(CellImpl cell, GridView parent)
                {
                    this.cell = cell;
                    this.parent = parent;
                }

                @Override
                public void UpdateStyle()
                {
                    UI.RequireUIThread();
                    parent.OnUpdateCellStyle(cell);
                }
            }

            private final Column column;
            private final Control control;
            private final Row row;

            public CellImpl(GridView gridView, Row row, Column column)
            {
                this.row = row;
                this.column = column;
                control = new CellControl(this, gridView);
            }

            public Column GetColumn()
            {
                return column;
            }

            public Row GetRow()
            {
                return row;
            }

private Object _Value;
            public Object Value() { return _Value; }
            public void Value(Object value) { _Value = value; }

            public Control GetControl()
            {
                return control;
            }
        }

        private final List<Column> columns = new ArrayList<>();
        private final List<Row> rows = new ArrayList<>();

        public Iterable<Cell> SelectCells(CellCondition condition)
        {
            ArrayList<Cell> result = new ArrayList<>();
            for(Row row : rows)
                for (Cell cell : row.GetCells())
                    if (condition.AppliesTo(cell))
                        result.add(cell);

            return result;
        }

        public interface CellCondition
        {
            boolean AppliesTo(Cell cell);
        }

        public Column GetColumn(String name)
        {
            for (Column column : columns)
                if (column.GetName() == name)
                    return column;

            return null;
        }

        public void SetHeadings(String[] names)
        {
            if (rows.size() > 0)
                throw new IllegalStateException();

            columns.clear();
            for (String name : names)
                columns.add(new ColumnImpl(name, this));
        }

        public Row NewRow()
        {
            RowImpl result = new RowImpl(this);
            rows.add(result);
            return result;
        }

        public void DeleteRow(Row toDelete)
        {
            rows.remove(toDelete);
        }

        @Override
        public final void UpdateStyle()
        {
            UI.RequireUIThread();
        }

        protected void OnUpdateCellStyle(Cell cell) { }
    }

