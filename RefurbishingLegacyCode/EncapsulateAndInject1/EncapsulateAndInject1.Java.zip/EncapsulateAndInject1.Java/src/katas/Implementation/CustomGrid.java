// Copyright 2018-2018 Hexagon Software LLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.


package katas.Implementation;

import katas.OtherTeamSettingsLibrary.RenderSettings;
import katas.ThirdPartyLibrary.GridView;
import katas.UIFramework.Control;

public final class CustomGrid extends GridView {
    private StyleRule[] _CustomFormattingRules;

    public StyleRule[] CustomFormattingRules() {
        return _CustomFormattingRules;
    }

    public void CustomFormattingRules(StyleRule[] value) {
        _CustomFormattingRules = value;
    }

    @Override
    protected void OnUpdateCellStyle(Cell cell) {
        super.OnUpdateCellStyle(cell);

        if (!RenderSettings.GetIsVisionImpared()) {
            cell.GetControl().SetBorderType(BorderType.Dotted);
            cell.GetControl().SetBorderWeight(0.5);
        } else {
            cell.GetControl().SetBorderType(Control.BorderType.Double);
            cell.GetControl().SetBorderWeight(2);
        }
        cell.GetControl().SetBorderCollapse(true);
    }

    public interface CellStyleWriter {
        void SetBorderType(BorderType borderType);

        void SetBorderWeight(double weight);

        void SetBackgroundColor(Color color);

        void SetTextColor(Color color);

        void SetTextWeight(double weight);

        void SetTextUnderline(boolean isUnderlined);

        void SetTextItalic(boolean isItalic);

        void SetBorderCollapse(boolean collapse);

        Cell GetCell();
    }

    private static class CellStyleWriterImpl implements CellStyleWriter {
        private final Cell target;

        public void UpdateStyle() {
            target.GetControl().UpdateStyle();
        }

        public void SetBorderType(BorderType borderType) {
            target.GetControl().SetBorderType(borderType);
        }

        public void SetBorderWeight(double weight) {
            target.GetControl().SetBorderWeight(weight);
        }

        public void SetBackgroundColor(Color color) {
            target.GetControl().SetBackgroundColor(color);
        }

        public void SetTextColor(Color color) {
            target.GetControl().SetTextColor(color);
        }

        public void SetTextWeight(double weight) {
            target.GetControl().SetTextWeight(weight);
        }

        public void SetTextUnderline(boolean isUnderlined) {
            target.GetControl().SetTextUnderline(isUnderlined);
        }

        public void SetTextItalic(boolean isItalic) {
            target.GetControl().SetTextItalic(isItalic);
        }

        public void SetBorderCollapse(boolean collapse) {
            target.GetControl().SetBorderCollapse(collapse);
        }

        public Cell GetCell() {
            return target;
        }

        public CellStyleWriterImpl(Cell target) {
            this.target = target;
        }
    }

    public static class StyleRule {
        private CellCondition _Condition;

        public CellCondition Condition() {
            return _Condition;
        }

        private StyleMod _StyleMod;

        public StyleMod StyleMod() {
            return _StyleMod;
        }

        public StyleRule(CellCondition condition, StyleMod styleMod) {
            _Condition = condition;
            _StyleMod = styleMod;
        }
    }
}

