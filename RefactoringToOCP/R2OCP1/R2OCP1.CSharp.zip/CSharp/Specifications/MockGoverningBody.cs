﻿// MIT License
// 
// Copyright (c) 2018 Hexagon Software LLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

using System.Collections.Generic;
using Implementation;

namespace Specifications
{
    internal class MockGoverningBody : GoverningBody
    {
        private readonly IDictionary<Account, int> gains = new Dictionary<Account, int>();
        private readonly IDictionary<Account, int> losses = new Dictionary<Account, int>();

        public override int GetTaxDeferredContributionLimit()
        {
            return 100000;
        }

        public override int GetLosses(Account account)
        {
            return GetValueOrDefault(account, losses);
        }

        public override void RecordLosses(Account account, int amount)
        {
            losses[account] = GetLosses(account) + amount;
        }

        public override int GetGains(Account account)
        {
            return GetValueOrDefault(account, gains);
        }

        public override void RecordGains(Account account, int amount)
        {
            gains[account] = GetGains(account) + amount;
        }

        private static int GetValueOrDefault(Account account, IDictionary<Account, int> dictionary)
        {
            if (!dictionary.ContainsKey(account))
                return 0;

            return dictionary[account];
        }
    }
}