﻿// MIT License
// 
// Copyright (c) 2018 Hexagon Software LLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
namespace Implementation
{
    public class Account
    {
        private abstract class AccountAmountTransaction : Transaction
        {
            protected readonly Account account;
            protected readonly int amount;

            protected AccountAmountTransaction(Account account, int amount)
            {
                this.account = account;
                this.amount = amount;
            }
        }

        private class CreditTransaction : AccountAmountTransaction
        {
            public CreditTransaction(Account account, int amount) : base(account, amount)
            {
            }

            public override void Commit()
            {
                account.Balance += amount;
            }
        }

        private class DebitTransaction : AccountAmountTransaction
        {
            public DebitTransaction(Account account, int amount) : base(account, amount)
            {
            }

            public override void Commit()
            {
                account.Balance -= amount;
            }
        }

        private Account()
        {

        }

        public int Balance { get; private set; }
        public GoverningBody GoverningBody { get; set; }

        public static Account GetInstance()
        {
            return new Account();
        }

        public Transaction Credit(int amount)
        {
            return new CreditTransaction(this, amount);
        }

        public Transaction Debit(int amount)
        {
            return new DebitTransaction(this, amount);
        }
    }
}
