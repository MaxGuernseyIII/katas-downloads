/*
 * MIT License
 *
 * Copyright (c) 2018 Hexagon Software LLC
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */

package katas;

public class Account {
    private abstract class AccountAmountTransaction extends Transaction {
        protected final int amount;

        protected AccountAmountTransaction(int amount) {
            this.amount = amount;
        }
    }

    private class CreditTransaction extends AccountAmountTransaction {
        public CreditTransaction(int amount) {
            super(amount);
        }

        @Override
        public void Commit() {
            Balance(Balance() + amount);
        }
    }

    private class DebitTransaction extends AccountAmountTransaction {
        public DebitTransaction(int amount) {
            super(amount);
        }

        @Override
        public void Commit() {
            Balance(Balance() - amount);
        }
    }

    private Account() {

    }

    private int _Balance;

    public int Balance() {
        return _Balance;
    }

    public void Balance(int value) {
        _Balance = value;
    }

    private GoverningBody _GoverningBody;

    public GoverningBody GoverningBody() {
        return _GoverningBody;
    }

    public void GoverningBody(GoverningBody value) {
        _GoverningBody = value;
    }

    public static Account GetInstance() {
        return new Account();
    }

    public Transaction Credit(int amount) {
        return new CreditTransaction(amount);
    }

    public Transaction Debit(int amount) {
        return new DebitTransaction(amount);
    }
}

